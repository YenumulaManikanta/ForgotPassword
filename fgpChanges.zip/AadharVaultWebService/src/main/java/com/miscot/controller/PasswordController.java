
package com.miscot.controller;

import javax.websocket.server.PathParam;
import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;*/
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.miscot.bean.UserMasterBean;
import com.miscot.dto.UserMaster;
import com.miscot.service.UserService;
@Controller
public class PasswordController {

	
	  @Autowired private UserService userService;
	  
 @RequestMapping(value = "/forgot", method = RequestMethod.GET)
	//public @ResponseBody String displayForgotPasswordPage(@PathVariable int id, @PathVariable String question, @PathVariable String answer, @PathVariable char confirm) {
		public @ResponseBody String displayForgotPasswordPage(@RequestParam("userid") String userid) {
		UserMaster usd=new UserMaster();
		usd.getID();
		return "";
	}
	
	
	@RequestMapping(value = "/matchForgotPassword", method = RequestMethod.POST)
	@ResponseBody
	public boolean searchUser(@ModelAttribute("userMasterBean") UserMasterBean userMasterBean)
	{
		boolean resp = false;
		try {
			resp = userService.matchForgotPassword(userMasterBean);
		} catch (Exception e) {
			e.printStackTrace();
		}
	return resp;
	}
	
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ModelAndView handleMissingParams(MissingServletRequestParameterException ex) {
		return new ModelAndView("redirect:login");
	}
}
/*

*/
