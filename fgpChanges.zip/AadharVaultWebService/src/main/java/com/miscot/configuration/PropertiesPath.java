package com.miscot.configuration;

public class PropertiesPath {
private String certPath;
private String pkcs11Config;
private String pin;
private String Key;
private String KeyStore;
private String Paddingtype;
private String storeadhaaruserid;
private String storeadhaarpasswd;
private String adhVlt_lk;
private String functionExecute;
private String privateCertificateName;
private String publicCertificateName;
private String clientCertificateName;
private String ipAddress;

public String getIpAddress() {
	return ipAddress;
}

public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
}

public String getClientCertificateName() {
	return clientCertificateName;
}

public void setClientCertificateName(String clientCertificateName) {
	this.clientCertificateName = clientCertificateName;
}

public String getPublicCertificateName() {
	return publicCertificateName;
}

public void setPublicCertificateName(String publicCertificateName) {
	this.publicCertificateName = publicCertificateName;
}

public String getPrivateCertificateName() {
	return privateCertificateName;
}

public void setPrivateCertificateName(String privateCertificateName) {
	this.privateCertificateName = privateCertificateName;
}

public String getFunctionExecute() {
	return functionExecute;
}

public void setFunctionExecute(String functionExecute) {
	this.functionExecute = functionExecute;
}

public String getPkcs11Config() {
	return pkcs11Config;
}

public void setPkcs11Config(String pkcs11Config) {
	this.pkcs11Config = pkcs11Config;
}

public String getPin() {
	return pin;
}

public void setPin(String pin) {
	this.pin = pin;
}

public String getKey() {
	return Key;
}

public void setKey(String key) {
	Key = key;
}

public String getKeyStore() {
	return KeyStore;
}

public void setKeyStore(String keyStore) {
	KeyStore = keyStore;
}

public String getPaddingtype() {
	return Paddingtype;
}

public void setPaddingtype(String paddingtype) {
	Paddingtype = paddingtype;
}

public String getStoreadhaaruserid() {
	return storeadhaaruserid;
}

public void setStoreadhaaruserid(String storeadhaaruserid) {
	this.storeadhaaruserid = storeadhaaruserid;
}

public String getStoreadhaarpasswd() {
	return storeadhaarpasswd;
}

public void setStoreadhaarpasswd(String storeadhaarpasswd) {
	this.storeadhaarpasswd = storeadhaarpasswd;
}

public String getAdhVlt_lk() {
	return adhVlt_lk;
}

public void setAdhVlt_lk(String adhVlt_lk) {
	this.adhVlt_lk = adhVlt_lk;
}

public String getCertPath() {
	return certPath;
}

public void setCertPath(String certPath) {
	this.certPath = certPath;
}
}
