package com.miscot.dto;

public class UserMaster {
	private int ID;
	private String QUESTION_TEXT;
	private String ANSWER_DATATYPE;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getQUESTION_TEXT() {
		return QUESTION_TEXT;
	}
	public void setQUESTION_TEXT(String qUESTION_TEXT) {
		QUESTION_TEXT = qUESTION_TEXT;
	}
	public String getANSWER_DATATYPE() {
		return ANSWER_DATATYPE;
	}
	public void setANSWER_DATATYPE(String aNSWER_DATATYPE) {
		ANSWER_DATATYPE = aNSWER_DATATYPE;
	}
	
	
	/*private int id;
	private String question;
	private String answer;
	private String confirm;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getConfirm() {
		return confirm;
	}
	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}*/

}
