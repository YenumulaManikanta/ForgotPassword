package com.miscot.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miscot.bean.UserMasterBean;
import com.miscot.model.UserDetails;
import com.miscot.repository.GetQueryImpl;
@Service("UserServiceImpl")
public class UserServiceImpl implements UserService{
	@Autowired 
	GetQueryImpl getQuery;
	public UserDetails displayForgotPasswordPage(int id) {
		// TODO Auto-generated method stub
		
		UserDetails usd=new UserDetails();
		usd.setId(1);
		
		return usd;
	}

	public UserDetails matchForgotPassword(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean matchForgotPassword(UserMasterBean userMasterBean) {
		
		String res=getQuery.checkForgetPasswordAnswer(userMasterBean.getUserID());
		int ansCount=0;
		List<String> items = Arrays.asList(res.split("\\s*,\\s*"));
		for(int i=0;i<items.size();i++)
		{
		    if(items.get(i).equals(userMasterBean.getAns1())) {
		    	ansCount++;
		    }
		    if(items.get(i).equals(userMasterBean.getAns2())) {
		    	ansCount++;
		    }
		    if(items.get(i).equals(userMasterBean.getAns3())) {
		    	ansCount++;
		    }
		    if(ansCount<3) {
		    	return false;
		    }
		}
		return true;
	}
	
}

