package com.miscot.service;

import com.miscot.bean.UserMasterBean;
import com.miscot.model.UserDetails;

/*
 * package com.miscot.springmvc.service;
 * 
 * import java.util.Optional; import com.miscot.springmvc.model.User;
 * 
 * public interface UserService { 
 * public Optional<User> findUserByEmail(String
 * email); public Optional<User> findUserByResetToken(String resetToken); public
 * void save(User user); }
 */
public interface UserService {
	
 public UserDetails displayForgotPasswordPage(int id);
 public boolean matchForgotPassword(UserMasterBean userMasterBean);
 
}