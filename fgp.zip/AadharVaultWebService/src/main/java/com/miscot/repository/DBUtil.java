package com.miscot.repository;

import java.security.spec.AlgorithmParameterSpec;
import java.sql.*;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import org.springframework.stereotype.Repository;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


@SuppressWarnings("restriction")
@Repository
public class DBUtil implements DBUtilInterface {
	public Connection conn = null;
	static String ConnectionStatus = "N";
	static String LastError = "";

	public static String ip_addr = "";
	@Autowired
    JdbcTemplate jdbcTemplate;




	public String retrieveUid(String encAdhNo) {
		// TODO Auto-generated method stub
		String query = "select uuid from tbl_vault where encAdhNo='" + encAdhNo + "'";
		String result = getSingleValues(query);
		//System.out.println("Result is" + result);
		return result;
	}

	public String getSingleValues(final String query) {
		// TODO Auto-generated method stub

		return (String) jdbcTemplate.query(query, new Object[] {}, new ResultSetExtractor<String>() {

			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				String Res = "";
				//System.out.println("Query" + query + "rs" + rs);

				if (rs != null) {
					while (rs.next()) {
						try {
							Res = RemoveNull(rs.getString(1));
							return Res;
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

				// set other properties

				return Res;
			}
		});

	}

	public int updateOrInsertValues(String query) {
		int i = jdbcTemplate.update(query);
		return i;
	}

	String algorithm = "DESede";
	String strPassword = "password12345678";
	public String encrypt(String Data){

		String encryptedValue = "";
		try {
		if (!Data.equalsIgnoreCase(null)) {

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			SecretKeySpec key = new SecretKeySpec(strPassword.getBytes(), "AES");
			AlgorithmParameterSpec paramSpec = new IvParameterSpec(
					strPassword.getBytes());
			cipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
			byte[] ecrypted = cipher.doFinal(Data.getBytes());
			encryptedValue = new BASE64Encoder().encode(ecrypted);
		}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return encryptedValue;
	}

	public String decrypt(String encryptedData) {
		String decryptedValue = "";
		try {
		if (!encryptedData.equalsIgnoreCase(null)) {
			SecretKeySpec key = new SecretKeySpec(strPassword.getBytes(), "AES");
			AlgorithmParameterSpec paramSpec = new IvParameterSpec(
					strPassword.getBytes());
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
			byte[] output = new BASE64Decoder().decodeBuffer(encryptedData);
			byte[] decrypted = cipher.doFinal(output);
			decryptedValue = new String(decrypted);

		}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return decryptedValue;
	}
	public String RemoveNull(String Val){
		String Res = "";
		if (Val == null) {
			Res = "";
		}
		else if (Val.equalsIgnoreCase("null")) {
			Res = "";
		}
		else {
			Res = Val;
		}
		return Res;
	}
	
	
}
