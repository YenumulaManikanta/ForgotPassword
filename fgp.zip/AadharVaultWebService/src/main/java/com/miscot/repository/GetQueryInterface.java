package com.miscot.repository;


public interface GetQueryInterface {
	String checkForgetPasswordAnswer(String txt_User_id);
}
